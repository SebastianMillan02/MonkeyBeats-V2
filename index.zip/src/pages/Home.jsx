const Home = () => {
  return <h1>Hola desde Home</h1>;
};

export default Home;